SADAF ALI CHANDIO - PORTFOLIO WEBSITE
=====================================

FOLDER / فولڈر
  index.html     -> main page / مرکزی صفحہ
  css/style.css  -> all design (colors, layout, animations) / ڈیزائن
  js/main.js     -> all JavaScript (menu, filter, forms, effects) / جاوا اسکرپٹ
  images/        -> all photos and project images / تمام تصویریں

HOW TO GO LIVE (FREE) / ویب سائٹ لائیو کیسے کریں
  Option 1 - Netlify Drop (easiest / سب سے آسان)
    1. Unzip this file / زپ فائل کھولیں
    2. Open app.netlify.com/drop in a browser
    3. Drag the whole folder (the one containing index.html) onto the page
    4. You get a live link in a few seconds / چند سیکنڈ میں لائیو لنک مل جائے گا

  Option 2 - GitHub Pages
    1. Create a GitHub repository and upload all files (keep the folders)
    2. Settings > Pages > Deploy from branch (main, root)

  Option 3 - Cloudflare Pages / Vercel: upload the folder the same way.

IMPORTANT: keep the folder structure exactly as it is.
           Do not move index.html away from css, js and images.

THINGS TO EDIT LATER / بعد میں بدلنے والی چیزیں
  - WhatsApp number: js/main.js (WA_NUMBER at the top), and in index.html
    search for 923092455834 (two links)
  - Social links: add inside the contact list in index.html
    (search for class="contact-list")
  - Add new project images: copy a file into images/ and copy one
    <article class="work"> block in index.html
  - Colors: css/style.css, top of the file (--lime, --bg and others)

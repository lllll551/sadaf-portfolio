var WA_NUMBER = "923092455834"; // real WhatsApp number: country code, no + or spaces
function tick(){ try{ document.getElementById("clock").textContent = "SINDH · " + new Date().toLocaleTimeString("en-GB",{timeZone:"Asia/Karachi"}); }catch(e){} }
tick(); setInterval(tick,1000);
var bars = document.querySelectorAll(".track i");
if("IntersectionObserver" in window){
 var io = new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ e.target.style.width = e.target.dataset.w + "%"; io.unobserve(e.target); } }); },{threshold:.4});
 bars.forEach(function(b){ io.observe(b); });
} else { bars.forEach(function(b){ b.style.width = b.dataset.w + "%"; }); }
var fb = document.querySelectorAll("#filters button"), items = document.querySelectorAll("#works .work");
fb.forEach(function(b){ b.addEventListener("click", function(){
 fb.forEach(function(x){ x.classList.remove("on"); }); b.classList.add("on");
 items.forEach(function(w){ w.classList.toggle("hide", b.dataset.f !== "all" && w.dataset.c !== b.dataset.f); });
}); });
document.getElementById("form").addEventListener("submit", function(e){
 e.preventDefault();
 var n = document.getElementById("name").value.trim(), m = document.getElementById("email").value.trim(), t = document.getElementById("text").value.trim(), msg = document.getElementById("msg");
 if(!n || !t){ msg.className = "msg err"; msg.textContent = "Please enter your name and message."; return; }
 if(!/^\S+@\S+\.\S+$/.test(m)){ msg.className = "msg err"; msg.textContent = "Please enter a valid email address."; return; }
 msg.className = "msg ok"; msg.textContent = "Opening WhatsApp...";
 window.open("https://wa.me/" + WA_NUMBER + "?text=" + encodeURIComponent("Hello Sadaf, I am " + n + " (" + m + "). " + t), "_blank", "noopener");
});
document.documentElement.classList.add("js");
var rm = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
if(!rm){
 var gl = document.getElementById("glow");
 window.addEventListener("mousemove", function(e){ gl.style.left = e.clientX + "px"; gl.style.top = e.clientY + "px"; });
 document.querySelectorAll(".work,.stat").forEach(function(c){
  c.addEventListener("mousemove", function(e){ var r = c.getBoundingClientRect(), x = (e.clientX - r.left)/r.width - .5, y = (e.clientY - r.top)/r.height - .5; c.style.transform = "perspective(700px) rotateY(" + (x*10) + "deg) rotateX(" + (-y*10) + "deg) translateY(-4px)"; });
  c.addEventListener("mouseleave", function(){ c.style.transform = ""; });
 });
}
var rv = document.querySelectorAll("h2,.step,.work,.row,.stat,.skill,details,.lead");
rv.forEach(function(el){ el.classList.add("rv"); });
if("IntersectionObserver" in window){
 var io2 = new IntersectionObserver(function(es){ es.forEach(function(e){ if(e.isIntersecting){ var t = e.target; t.classList.add("in"); io2.unobserve(t); setTimeout(function(){ t.classList.remove("rv","in"); }, 900); } }); },{threshold:.15});
 rv.forEach(function(el){ io2.observe(el); });
} else { rv.forEach(function(el){ el.classList.add("in"); }); }
document.getElementById("fbform").addEventListener("submit", function(e){
 e.preventDefault();
 var n = document.getElementById("fname").value.trim(), r = document.getElementById("frate").value, t = document.getElementById("ftext").value.trim(), m = document.getElementById("fmsg");
 if(!n || !t){ m.className = "msg err"; m.textContent = "Please enter your name and feedback."; return; }
 m.className = "msg ok"; m.textContent = "Thank you! Opening WhatsApp...";
 window.open("https://wa.me/" + WA_NUMBER + "?text=" + encodeURIComponent("Feedback from " + n + " (" + r + "/5): " + t), "_blank", "noopener");
});
var pg = document.getElementById("progress");
window.addEventListener("scroll", function(){ var h = document.documentElement; pg.style.width = (h.scrollTop / (h.scrollHeight - h.clientHeight) * 100) + "%"; }, {passive:true});
if(!rm && window.matchMedia("(pointer:fine)").matches){
 var ring = document.getElementById("ring");
 window.addEventListener("mousemove", function(e){ ring.classList.add("on"); ring.style.left = e.clientX + "px"; ring.style.top = e.clientY + "px"; ring.classList.toggle("big", !!e.target.closest("a,button,summary,.work,input,textarea,select")); });
 document.querySelectorAll(".pill").forEach(function(b){
  b.addEventListener("mousemove", function(e){ var r = b.getBoundingClientRect(); b.style.transform = "translate(" + ((e.clientX - r.left - r.width/2)*.25) + "px," + ((e.clientY - r.top - r.height/2)*.35) + "px)"; });
  b.addEventListener("mouseleave", function(){ b.style.transform = ""; });
 });
}
document.getElementById("wa").href = "https://wa.me/" + WA_NUMBER;
if(!rm && "IntersectionObserver" in window){
 var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ#%&*";
 var sio = new IntersectionObserver(function(es){ es.forEach(function(e){ if(!e.isIntersecting) return; sio.unobserve(e.target);
  var el = e.target;
  if(el.tagName === "H2"){ var t = el.textContent, i = 0; el.setAttribute("aria-label", t);
   var iv = setInterval(function(){ el.textContent = t.split("").map(function(c, k){ return (k < i || c === " ") ? c : chars[Math.floor(Math.random()*chars.length)]; }).join(""); i += 1.3; if(i >= t.length){ el.textContent = t; clearInterval(iv); } }, 35);
  } else { var raw = el.textContent, n = parseInt(raw, 10), suf = raw.replace(/[0-9]/g, ""), len = raw.replace(/[^0-9]/g, "").length, s = 0;
   var cv = setInterval(function(){ s += Math.max(1, Math.ceil(n/30)); if(s >= n){ s = n; clearInterval(cv); } el.textContent = String(s).padStart(len, "0") + suf; }, 40); }
 }); }, {threshold:.6});
 document.querySelectorAll("h2,.stat b").forEach(function(el){ sio.observe(el); });
}
var hp = document.querySelector(".photo img"), op = document.getElementById("opimg");
if(hp && op){ op.src = hp.src; }
var lb = document.getElementById("lb"), lbi = document.getElementById("lbimg"), lastZ = null;
function closeLb(){ lb.hidden = true; lbi.removeAttribute("src"); if(lastZ){ lastZ.focus(); } }
document.addEventListener("click", function(e){ var z = e.target.closest(".zoom"); if(z){ lastZ = z; var im = z.querySelector("img"); lbi.src = im.src; lbi.alt = im.alt; lb.hidden = false; document.getElementById("lbx").focus(); } else if(!lb.hidden && e.target.closest("#lb")){ closeLb(); } });
document.addEventListener("keydown", function(e){ if(e.key === "Escape" && !lb.hidden){ closeLb(); } });
var mb = document.getElementById("menuBtn"), nl = document.getElementById("navlinks");
mb.addEventListener("click", function(){ var o = nl.classList.toggle("open"); mb.setAttribute("aria-expanded", o); mb.textContent = o ? "Close" : "Menu"; });
nl.addEventListener("click", function(e){ if(e.target.closest("a")){ nl.classList.remove("open"); mb.setAttribute("aria-expanded","false"); mb.textContent = "Menu"; } });
document.addEventListener("keydown", function(e){ if(e.key === "Escape" && nl.classList.contains("open")){ nl.classList.remove("open"); mb.setAttribute("aria-expanded","false"); mb.textContent = "Menu"; mb.focus(); } if(e.key === "Tab" && !lb.hidden){ e.preventDefault(); document.getElementById("lbx").focus(); } });
document.getElementById("yr").textContent = new Date().getFullYear();
